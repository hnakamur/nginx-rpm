Documentation is available here:
https://github.com/arut/nginx-rtmp-module/wiki
