ffplay -loglevel verbose "rtmp://localhost/myapp/mystream"
