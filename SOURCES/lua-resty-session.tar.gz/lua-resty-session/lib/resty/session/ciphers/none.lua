local cipher = {}

function cipher.new()
    return cipher
end

function cipher.encrypt(_, data)
    return data
end

function cipher.decrypt(_, data)
    return data
end

return cipher
