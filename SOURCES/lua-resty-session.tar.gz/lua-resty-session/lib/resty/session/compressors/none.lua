local compressor = {}

function compressor.new()
    return compressor
end

function compressor.compress(_, data)
    return data
end

function compressor.decompress(_, data)
    return data
end

return compressor
