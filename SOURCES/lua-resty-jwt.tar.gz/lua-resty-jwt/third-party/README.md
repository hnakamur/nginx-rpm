# Third Party Libraries

This folder contains important 3rd party libraries that not available on luarocks.

- resty/hmac.lua [lua-resty-hmac](https://github.com/jkeys089/lua-resty-hmac)
