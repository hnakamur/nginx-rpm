**Note that support requests for Shibboleth configuration and Nginx or web
server setup should be directed to the Shibboleth community users mailing
list.  See <https://www.shibboleth.net/community/lists/> for details.**
