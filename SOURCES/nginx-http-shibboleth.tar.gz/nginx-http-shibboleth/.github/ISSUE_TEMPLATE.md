### Description of Issue/Question
(Be as detailed as possible)

### Setup
(Please provide relevant configuration files; be sure to remove sensitive
info)

### Steps to Reproduce Issue
(Include debug logs if possible, see
http://nginx.org/en/docs/debugging_log.html; be sure to remove sensitive info)

### Versions and Systems
(`nginx -V`, `shibd -v` (and compile options), OS type and version)
