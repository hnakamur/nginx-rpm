Deprecated
==========

This module is deprecated since all of its functionality was added to nginx' own secure_link module.

