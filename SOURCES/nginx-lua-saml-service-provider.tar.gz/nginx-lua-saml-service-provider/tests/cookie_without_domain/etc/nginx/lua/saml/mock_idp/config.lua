return {
    response = {
        id_attr = {
            attrName = "ID", nodeName = "Response",
            nsHref = "urn:oasis:names:tc:SAML:2.0:protocol"
        },
        attribute_names = {"mail"},
    }
}
