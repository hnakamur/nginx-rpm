dofile('/etc/nginx/lua/service_provider_init.lua')
dofile('/etc/nginx/lua/test_init.lua')
dofile('/etc/nginx/lua/mock_idp_init.lua')
