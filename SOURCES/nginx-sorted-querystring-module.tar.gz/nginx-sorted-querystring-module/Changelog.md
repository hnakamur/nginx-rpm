### 0.3
- Add support to the module works as a dynamic module

### 0.2
- [bug fix] Correct the variable length when all parameters were filtered

### 0.1
- Initial release
