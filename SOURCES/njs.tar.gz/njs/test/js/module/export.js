var a = 1;

export default {a}
export default {a}
