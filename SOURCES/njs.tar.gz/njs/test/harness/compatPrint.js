if (typeof print !== 'function') {
    print = console.log;
}
