var _export = {};

export default (_export.sum = function(a, b) { return a + b; },
                _export.prod = function(a, b) { return a * b; },
                _export);
